-- AllBookd: Payments table patch
-- Run this in Supabase SQL Editor BEFORE deploying the new Payments.jsx

-- 1. Add client_id column (allows payments without an invoice)
ALTER TABLE payments ADD COLUMN IF NOT EXISTS client_id uuid REFERENCES clients(id);

-- 2. Add reference column (Venmo confirmation, check number, etc.)
ALTER TABLE payments ADD COLUMN IF NOT EXISTS reference text;

-- 3. Update method constraint to support all payment types
-- First drop existing constraint if any
ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_method_check;

-- Add new constraint with all methods
ALTER TABLE payments ADD CONSTRAINT payments_method_check 
  CHECK (method IN ('cash', 'venmo', 'zelle', 'card', 'bank_transfer', 'check', 'other'));

-- 4. Update RLS policy for payments to allow client_id based access
-- (existing org_id policy should already cover this, but let's make sure SELECT works)
DROP POLICY IF EXISTS "Users can view own org payments" ON payments;
CREATE POLICY "Users can view own org payments" ON payments
  FOR SELECT USING (org_id = public.user_org_id());

DROP POLICY IF EXISTS "Users can insert own org payments" ON payments;
CREATE POLICY "Users can insert own org payments" ON payments
  FOR INSERT WITH CHECK (org_id = public.user_org_id());

DROP POLICY IF EXISTS "Users can update own org payments" ON payments;
CREATE POLICY "Users can update own org payments" ON payments
  FOR UPDATE USING (org_id = public.user_org_id());

DROP POLICY IF EXISTS "Users can delete own org payments" ON payments;
CREATE POLICY "Users can delete own org payments" ON payments
  FOR DELETE USING (org_id = public.user_org_id());
